import { redirect } from "next/navigation";
import { dashboardPathForRole, requireUser } from "@/lib/auth";

export default async function DashboardIndexPage() {
  const user = await requireUser();
  redirect(dashboardPathForRole(user.role));
}
