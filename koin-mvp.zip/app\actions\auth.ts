"use server";

import { redirect } from "next/navigation";
import { createAdminClient } from "@/lib/supabase/admin";
import { createClient } from "@/lib/supabase/server";
import { dashboardPathForRole } from "@/lib/auth";
import { formString } from "@/lib/format";
import type { Role } from "@/lib/types";

function withError(path: string, message: string): never {
  redirect(`${path}?error=${encodeURIComponent(message)}`);
}

async function registerPublicUser(formData: FormData, role: Extract<Role, "PARENT" | "CANTEEN">) {
  const email = formString(formData, "email").toLowerCase();
  const password = formString(formData, "password");
  const fullName = formString(formData, "full_name");
  const phone = formString(formData, "phone");
  const canteenName = formString(formData, "canteen_name");
  const path = role === "PARENT" ? "/register/parent" : "/register/canteen";

  if (!email || !password || !fullName) withError(path, "Nama, email, dan password wajib diisi.");
  if (password.length < 6) withError(path, "Password minimal 6 karakter.");

  const admin = createAdminClient();
  const { data: created, error: createError } = await admin.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
    user_metadata: { full_name: fullName, role }
  });

  if (createError || !created.user) withError(path, createError?.message ?? "Gagal membuat akun.");
  const userId = created.user.id;

  const { error: profileError } = await admin.from("users").insert({
    id: userId,
    email,
    full_name: fullName,
    role
  });

  if (profileError) {
    await admin.auth.admin.deleteUser(userId);
    withError(path, profileError.message);
  }

  if (role === "PARENT") {
    const { error } = await admin.from("parents").insert({ user_id: userId, phone });
    if (error) {
      await admin.auth.admin.deleteUser(userId);
      withError(path, error.message);
    }
  }

  if (role === "CANTEEN") {
    const { error } = await admin
      .from("canteens")
      .insert({ user_id: userId, name: canteenName || fullName, phone });
    if (error) {
      await admin.auth.admin.deleteUser(userId);
      withError(path, error.message);
    }
  }

  redirect(`/login?success=${encodeURIComponent("Akun berhasil dibuat. Silakan login.")}`);
}

export async function registerParentAction(formData: FormData) {
  await registerPublicUser(formData, "PARENT");
}

export async function registerCanteenAction(formData: FormData) {
  await registerPublicUser(formData, "CANTEEN");
}

export async function loginAction(formData: FormData) {
  const email = formString(formData, "email").toLowerCase();
  const password = formString(formData, "password");
  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithPassword({ email, password });

  if (error) withError("/login", error.message);

  const {
    data: { user }
  } = await supabase.auth.getUser();

  if (!user) withError("/login", "Login gagal.");

  const { data: profile, error: profileError } = await supabase
    .from("users")
    .select("role")
    .eq("id", user.id)
    .single();

  if (profileError || !profile) withError("/login", "Profil belum tersedia.");
  redirect(dashboardPathForRole(profile.role as Role));
}

export async function logoutAction() {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect("/login");
}
