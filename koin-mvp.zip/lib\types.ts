export type Role = "ADMIN" | "PARENT" | "CHILD" | "CANTEEN";
export type CardStatus = "ACTIVE" | "BLOCKED" | "INACTIVE";
export type TransactionType = "TOPUP" | "PURCHASE";
export type TransactionStatus = "SUCCESS" | "FAILED";

export type AppUser = {
  id: string;
  email: string;
  full_name: string;
  role: Role;
  created_at: string;
};

export type ChildSummary = {
  id: string;
  full_name: string;
  email: string;
  daily_limit_amount: number;
  card_uid: string | null;
  card_status: CardStatus | null;
  balance: number;
};
