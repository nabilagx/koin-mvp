import Link from "next/link";
import { ArrowRight, CreditCard, ShieldCheck, WalletCards } from "lucide-react";

export default function LandingPage() {
  return (
    <main className="min-h-screen bg-paper">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-5 py-5">
        <Link href="/" className="text-xl font-black tracking-tight">
          KOIN
        </Link>
        <div className="flex items-center gap-2">
          <Link href="/login" className="btn-secondary">
            Login
          </Link>
          <Link href="/register/parent" className="btn-primary">
            Daftar
          </Link>
        </div>
      </nav>
      <section className="mx-auto grid max-w-6xl items-center gap-10 px-5 pb-16 pt-10 md:grid-cols-[1.05fr_0.95fr]">
        <div>
          <p className="text-sm font-bold uppercase tracking-[0.2em] text-mint">
            MVP uang saku digital sekolah
          </p>
          <h1 className="mt-4 max-w-3xl text-5xl font-black leading-tight tracking-tight sm:text-6xl">
            KOIN
          </h1>
          <p className="mt-5 max-w-2xl text-lg leading-8 text-ink/72">
            Kelola saldo anak, kartu kantin, limit harian, dan transaksi sekolah
            dalam satu alur sederhana untuk parent, child, canteen, dan admin.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Link href="/register/parent" className="btn-primary">
              Register Parent
              <ArrowRight size={16} />
            </Link>
            <Link href="/register/canteen" className="btn-secondary">
              Register Canteen
            </Link>
          </div>
        </div>
        <div className="panel rounded-lg p-5">
          <div className="rounded-md bg-ink p-5 text-white">
            <div className="flex items-center justify-between">
              <span className="text-sm font-semibold text-white/70">Kartu Anak</span>
              <CreditCard size={22} />
            </div>
            <p className="mt-10 text-2xl font-black">KOIN CARD</p>
            <p className="mt-2 text-sm text-white/65">Tap di kantin, saldo dicek otomatis.</p>
          </div>
          <div className="mt-4 grid grid-cols-2 gap-4">
            <div className="rounded-md border border-line p-4">
              <WalletCards className="text-mint" size={24} />
              <p className="mt-4 text-sm text-ink/60">Saldo simulasi</p>
              <p className="text-xl font-black">Rp125.000</p>
            </div>
            <div className="rounded-md border border-line p-4">
              <ShieldCheck className="text-leaf" size={24} />
              <p className="mt-4 text-sm text-ink/60">Limit harian</p>
              <p className="text-xl font-black">Rp25.000</p>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
