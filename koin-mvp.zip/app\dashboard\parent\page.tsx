import { AppShell } from "@/components/AppShell";
import { assignCardAction, createChildAction, topUpChildAction } from "@/app/actions/parent";
import { formatRupiah } from "@/lib/format";
import { requireUser } from "@/lib/auth";
import { createAdminClient } from "@/lib/supabase/admin";
import type { ChildSummary } from "@/lib/types";

type ParentChildRow = {
  id: string;
  daily_limit_amount: number | string | null;
  users?: { email?: string | null; full_name?: string | null } | null;
  wallets?: Array<{ balance?: number | string | null }> | null;
  cards?: Array<{ card_uid?: string | null; status?: ChildSummary["card_status"] }> | null;
};

async function getParentChildren(userId: string) {
  const admin = createAdminClient();
  const { data: parent } = await admin.from("parents").select("id").eq("user_id", userId).single();
  if (!parent) return [];

  const { data: children } = await admin
    .from("children")
    .select("id,daily_limit_amount,users:user_id(email,full_name),wallets(balance),cards(card_uid,status)")
    .eq("parent_id", parent.id)
    .order("created_at", { ascending: false });

  return ((children ?? []) as ParentChildRow[]).map((child) => ({
    id: child.id,
    full_name: child.users?.full_name ?? "-",
    email: child.users?.email ?? "-",
    daily_limit_amount: Number(child.daily_limit_amount ?? 0),
    card_uid: child.cards?.[0]?.card_uid ?? null,
    card_status: child.cards?.[0]?.status ?? null,
    balance: Number(child.wallets?.[0]?.balance ?? 0)
  })) as ChildSummary[];
}

export default async function ParentDashboardPage() {
  const user = await requireUser(["PARENT"]);
  const children = await getParentChildren(user.id);

  return (
    <AppShell user={user} title="Parent Dashboard">
      <div className="grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
        <section className="panel rounded-lg p-5">
          <h2 className="text-lg font-black">Tambah Anak</h2>
          <form action={createChildAction} className="mt-4 space-y-4">
            <label className="block text-sm font-semibold">Nama anak<input className="field mt-1" name="full_name" required /></label>
            <label className="block text-sm font-semibold">Email login anak<input className="field mt-1" name="email" type="email" required /></label>
            <label className="block text-sm font-semibold">Password anak<input className="field mt-1" name="password" type="password" minLength={6} required /></label>
            <label className="block text-sm font-semibold">Limit harian<input className="field mt-1" name="daily_limit_amount" type="number" min={0} defaultValue={25000} /></label>
            <button className="btn-primary w-full" type="submit">Buat child</button>
          </form>
        </section>
        <section>
          <h2 className="text-lg font-black">Anak Terdaftar</h2>
          <p className="text-sm text-ink/60">{children.length} child aktif di akun ini</p>
          <div className="mt-4 grid gap-4">
            {children.map((child) => (
              <article className="panel rounded-lg p-5" key={child.id}>
                <h3 className="text-lg font-black">{child.full_name}</h3>
                <p className="text-sm text-ink/60">{child.email}</p>
                <div className="mt-4 grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
                  <div><p className="text-ink/55">Saldo</p><p className="font-black">{formatRupiah(child.balance)}</p></div>
                  <div><p className="text-ink/55">Limit harian</p><p className="font-black">{formatRupiah(child.daily_limit_amount)}</p></div>
                  <div><p className="text-ink/55">Card UID</p><p className="font-black">{child.card_uid ?? "Belum ada"}</p></div>
                  <div><p className="text-ink/55">Status kartu</p><p className="font-black">{child.card_status ?? "-"}</p></div>
                </div>
                <div className="mt-5 grid gap-3 md:grid-cols-2">
                  <form action={topUpChildAction} className="flex gap-2">
                    <input type="hidden" name="child_id" value={child.id} />
                    <input className="field" name="amount" type="number" min={1} placeholder="Nominal top up" required />
                    <button className="btn-primary" type="submit">Top up</button>
                  </form>
                  <form action={assignCardAction} className="flex gap-2">
                    <input type="hidden" name="child_id" value={child.id} />
                    <input className="field" name="card_uid" placeholder="CARD-001" required />
                    <button className="btn-secondary" type="submit">Assign</button>
                  </form>
                </div>
              </article>
            ))}
            {children.length === 0 ? <div className="panel rounded-lg p-6 text-sm text-ink/65">Belum ada child.</div> : null}
          </div>
        </section>
      </div>
    </AppShell>
  );
}
