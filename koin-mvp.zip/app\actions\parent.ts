"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { getCurrentUserProfile } from "@/lib/auth";
import { formNumber, formString } from "@/lib/format";
import { createAdminClient } from "@/lib/supabase/admin";

async function requireParentContext() {
  const profile = await getCurrentUserProfile();
  if (!profile) redirect("/login");
  if (profile.role !== "PARENT") redirect("/dashboard");

  const admin = createAdminClient();
  const { data: parent, error } = await admin
    .from("parents")
    .select("id,user_id")
    .eq("user_id", profile.id)
    .single();

  if (error || !parent) throw new Error("Profil parent belum tersedia.");
  return { profile, parent, admin };
}

async function assertOwnChild(childId: string) {
  const context = await requireParentContext();
  const { data: child, error } = await context.admin
    .from("children")
    .select("id,parent_id")
    .eq("id", childId)
    .eq("parent_id", context.parent.id)
    .single();

  if (error || !child) throw new Error("Child tidak ditemukan untuk parent ini.");
  return { ...context, child };
}

export async function createChildAction(formData: FormData) {
  const { parent, admin } = await requireParentContext();
  const fullName = formString(formData, "full_name");
  const email = formString(formData, "email").toLowerCase();
  const password = formString(formData, "password");
  const dailyLimitAmount = formNumber(formData, "daily_limit_amount");

  if (!fullName || !email || password.length < 6) {
    throw new Error("Nama, email, dan password child minimal 6 karakter wajib diisi.");
  }

  const { data: created, error: createError } = await admin.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
    user_metadata: { full_name: fullName, role: "CHILD" }
  });

  if (createError || !created.user) throw new Error(createError?.message ?? "Gagal membuat akun child.");
  const childUserId = created.user.id;

  const { error: profileError } = await admin.from("users").insert({
    id: childUserId,
    email,
    full_name: fullName,
    role: "CHILD"
  });

  if (profileError) {
    await admin.auth.admin.deleteUser(childUserId);
    throw new Error(profileError.message);
  }

  const { data: child, error: childError } = await admin
    .from("children")
    .insert({
      user_id: childUserId,
      parent_id: parent.id,
      daily_limit_amount: Math.max(dailyLimitAmount, 0)
    })
    .select("id")
    .single();

  if (childError || !child) {
    await admin.auth.admin.deleteUser(childUserId);
    throw new Error(childError?.message ?? "Gagal membuat child.");
  }

  const { error: walletError } = await admin.from("wallets").insert({
    child_id: child.id,
    balance: 0
  });

  if (walletError) throw new Error(walletError.message);
  revalidatePath("/dashboard/parent");
}

export async function topUpChildAction(formData: FormData) {
  const childId = formString(formData, "child_id");
  const amount = formNumber(formData, "amount");
  if (!childId || amount <= 0) throw new Error("Child dan nominal top up wajib valid.");

  const { admin } = await assertOwnChild(childId);
  const { data: wallet, error: walletError } = await admin
    .from("wallets")
    .select("id,balance")
    .eq("child_id", childId)
    .single();

  if (walletError || !wallet) throw new Error("Wallet child belum tersedia.");
  const nextBalance = Number(wallet.balance) + amount;

  const { error: updateError } = await admin
    .from("wallets")
    .update({ balance: nextBalance })
    .eq("id", wallet.id);

  if (updateError) throw new Error(updateError.message);

  await admin.from("transactions").insert({
    child_id: childId,
    type: "TOPUP",
    amount,
    status: "SUCCESS",
    description: "Top up saldo simulasi oleh parent",
    balance_before: wallet.balance,
    balance_after: nextBalance
  });

  revalidatePath("/dashboard/parent");
}

export async function assignCardAction(formData: FormData) {
  const childId = formString(formData, "child_id");
  const cardUid = formString(formData, "card_uid");
  if (!childId || !cardUid) throw new Error("Child dan card UID wajib diisi.");

  const { admin } = await assertOwnChild(childId);
  const { data: existing } = await admin.from("cards").select("id").eq("child_id", childId).maybeSingle();
  const payload = { child_id: childId, card_uid: cardUid, status: "ACTIVE" };
  const { error } = existing
    ? await admin.from("cards").update(payload).eq("id", existing.id)
    : await admin.from("cards").insert(payload);

  if (error) throw new Error(error.message);
  revalidatePath("/dashboard/parent");
}
