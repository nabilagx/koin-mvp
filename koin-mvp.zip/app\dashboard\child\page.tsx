import { AppShell } from "@/components/AppShell";
import { requireUser } from "@/lib/auth";
import { formatRupiah } from "@/lib/format";
import { createAdminClient } from "@/lib/supabase/admin";

type ChildDashboardRow = {
  id: string;
  daily_limit_amount: number | string;
  cards?: Array<{ card_uid?: string | null; status?: string | null }> | null;
  wallets?: Array<{ balance?: number | string | null }> | null;
};

type ChildTransactionRow = {
  id: string;
  type: "TOPUP" | "PURCHASE";
  amount: number | string;
  status: "SUCCESS" | "FAILED";
  description: string | null;
  created_at: string;
};

async function getChildDashboard(userId: string) {
  const admin = createAdminClient();
  const { data: child } = await admin
    .from("children")
    .select("id,daily_limit_amount,cards(card_uid,status),wallets(balance)")
    .eq("user_id", userId)
    .single();

  if (!child) return null;

  const { data: transactions } = await admin
    .from("transactions")
    .select("id,type,amount,status,description,created_at")
    .eq("child_id", child.id)
    .order("created_at", { ascending: false })
    .limit(20);

  return { child: child as ChildDashboardRow, transactions: (transactions ?? []) as ChildTransactionRow[] };
}

export default async function ChildDashboardPage() {
  const user = await requireUser(["CHILD"]);
  const data = await getChildDashboard(user.id);

  return (
    <AppShell user={user} title="Child Dashboard">
      {!data ? (
        <div className="panel rounded-lg p-6 text-sm text-ink/65">Profil child belum tersedia.</div>
      ) : (
        <div className="grid gap-6 lg:grid-cols-[0.8fr_1.2fr]">
          <section className="panel rounded-lg p-5">
            <p className="text-sm font-semibold text-ink/60">Saldo saat ini</p>
            <p className="mt-2 text-4xl font-black">{formatRupiah(Number(data.child.wallets?.[0]?.balance ?? 0))}</p>
            <div className="mt-6 grid grid-cols-2 gap-3 text-sm">
              <div className="rounded-md border border-line p-3"><p className="text-ink/55">Limit harian</p><p className="font-black">{formatRupiah(Number(data.child.daily_limit_amount))}</p></div>
              <div className="rounded-md border border-line p-3"><p className="text-ink/55">Kartu</p><p className="font-black">{data.child.cards?.[0]?.status ?? "-"}</p></div>
            </div>
          </section>
          <section className="panel rounded-lg p-5">
            <h2 className="text-lg font-black">Riwayat Transaksi</h2>
            <div className="mt-4 divide-y divide-line">
              {data.transactions.map((transaction) => (
                <div className="flex items-center justify-between gap-4 py-3" key={transaction.id}>
                  <div><p className="font-semibold">{transaction.type}</p><p className="text-sm text-ink/60">{transaction.description}</p></div>
                  <div className="text-right"><p className="font-black">{formatRupiah(Number(transaction.amount))}</p><p className={transaction.status === "SUCCESS" ? "text-sm text-leaf" : "text-sm text-red-600"}>{transaction.status}</p></div>
                </div>
              ))}
            </div>
          </section>
        </div>
      )}
    </AppShell>
  );
}
