import Link from "next/link";
import { AuthNotice } from "@/components/AuthNotice";
import { loginAction } from "@/app/actions/auth";

export default async function LoginPage({
  searchParams
}: {
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  const params = await searchParams;

  return (
    <main className="grid min-h-screen place-items-center bg-paper px-5 py-10">
      <div className="panel w-full max-w-md rounded-lg p-6">
        <Link href="/" className="text-xl font-black">KOIN</Link>
        <h1 className="mt-8 text-2xl font-black">Login</h1>
        <p className="mt-2 text-sm text-ink/65">Masuk sebagai admin, parent, child, atau canteen.</p>
        <div className="mt-5"><AuthNotice error={params.error} success={params.success} /></div>
        <form action={loginAction} className="mt-5 space-y-4">
          <label className="block text-sm font-semibold">
            Email
            <input className="field mt-1" name="email" type="email" required />
          </label>
          <label className="block text-sm font-semibold">
            Password
            <input className="field mt-1" name="password" type="password" required />
          </label>
          <button className="btn-primary w-full" type="submit">Login</button>
        </form>
        <div className="mt-5 grid grid-cols-2 gap-3 text-sm">
          <Link className="btn-secondary" href="/register/parent">Register Parent</Link>
          <Link className="btn-secondary" href="/register/canteen">Register Canteen</Link>
        </div>
      </div>
    </main>
  );
}
