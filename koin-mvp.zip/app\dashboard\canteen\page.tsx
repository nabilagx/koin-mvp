import { createCanteenTransactionAction } from "@/app/actions/canteen";
import { AppShell } from "@/components/AppShell";
import { requireUser } from "@/lib/auth";
import { formatRupiah } from "@/lib/format";
import { createAdminClient } from "@/lib/supabase/admin";

type CanteenTransactionRow = {
  id: string;
  amount: number | string;
  status: "SUCCESS" | "FAILED";
  description: string | null;
  children?: { users?: { full_name?: string | null } | null } | null;
};

async function getRecentCanteenTransactions(userId: string) {
  const admin = createAdminClient();
  const { data: canteen } = await admin.from("canteens").select("id").eq("user_id", userId).single();
  if (!canteen) return [];

  const { data } = await admin
    .from("transactions")
    .select("id,amount,status,description,created_at,children(users:user_id(full_name))")
    .eq("canteen_id", canteen.id)
    .order("created_at", { ascending: false })
    .limit(10);

  return data ?? [];
}

export default async function CanteenDashboardPage() {
  const user = await requireUser(["CANTEEN"]);
  const transactions = await getRecentCanteenTransactions(user.id);

  return (
    <AppShell user={user} title="Canteen Dashboard">
      <div className="grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
        <section className="panel rounded-lg p-5">
          <h2 className="text-lg font-black">Transaksi Kartu</h2>
          <p className="mt-1 text-sm text-ink/60">Masukkan card UID dan nominal. Sistem akan cek status kartu, saldo, dan limit harian.</p>
          <form action={createCanteenTransactionAction} className="mt-5 space-y-4">
            <label className="block text-sm font-semibold">Card UID<input className="field mt-1" name="card_uid" placeholder="CARD-001" required /></label>
            <label className="block text-sm font-semibold">Nominal<input className="field mt-1" name="amount" type="number" min={1} required /></label>
            <label className="block text-sm font-semibold">Catatan<input className="field mt-1" name="description" placeholder="Makan siang" /></label>
            <button className="btn-primary w-full" type="submit">Proses transaksi</button>
          </form>
        </section>
        <section className="panel rounded-lg p-5">
          <h2 className="text-lg font-black">Riwayat Transaksi Kantin</h2>
          <div className="mt-4 divide-y divide-line">
            {(transactions as CanteenTransactionRow[]).map((transaction) => (
              <div className="flex items-center justify-between gap-4 py-3" key={transaction.id}>
                <div><p className="font-semibold">{transaction.children?.users?.full_name ?? "Child"}</p><p className="text-sm text-ink/60">{transaction.description}</p></div>
                <div className="text-right"><p className="font-black">{formatRupiah(Number(transaction.amount))}</p><p className={transaction.status === "SUCCESS" ? "text-sm text-leaf" : "text-sm text-red-600"}>{transaction.status}</p></div>
              </div>
            ))}
            {transactions.length === 0 ? <p className="py-6 text-sm text-ink/65">Belum ada transaksi kantin.</p> : null}
          </div>
        </section>
      </div>
    </AppShell>
  );
}
