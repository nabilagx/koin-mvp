import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./lib/**/*.{js,ts,jsx,tsx,mdx}"
  ],
  theme: {
    extend: {
      colors: {
        ink: "#17211d",
        mint: "#0f8f6b",
        leaf: "#46a758",
        paper: "#f7f5ef",
        line: "#ded8c9"
      },
      boxShadow: {
        soft: "0 16px 40px rgba(23, 33, 29, 0.10)"
      }
    }
  },
  plugins: []
};

export default config;
