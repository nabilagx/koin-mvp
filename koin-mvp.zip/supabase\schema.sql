create extension if not exists "pgcrypto";

do $$ begin
  create type public.user_role as enum ('ADMIN', 'PARENT', 'CHILD', 'CANTEEN');
exception when duplicate_object then null;
end $$;

do $$ begin
  create type public.card_status as enum ('ACTIVE', 'BLOCKED', 'INACTIVE');
exception when duplicate_object then null;
end $$;

do $$ begin
  create type public.transaction_type as enum ('TOPUP', 'PURCHASE');
exception when duplicate_object then null;
end $$;

do $$ begin
  create type public.transaction_status as enum ('SUCCESS', 'FAILED');
exception when duplicate_object then null;
end $$;

create table if not exists public.users (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null unique,
  full_name text not null,
  role public.user_role not null,
  created_at timestamptz not null default now()
);

create table if not exists public.parents (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references public.users(id) on delete cascade,
  phone text,
  created_at timestamptz not null default now()
);

create table if not exists public.children (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references public.users(id) on delete cascade,
  parent_id uuid not null references public.parents(id) on delete cascade,
  daily_limit_amount numeric(14, 2) not null default 25000 check (daily_limit_amount >= 0),
  created_at timestamptz not null default now()
);

create table if not exists public.canteens (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references public.users(id) on delete cascade,
  name text not null,
  phone text,
  created_at timestamptz not null default now()
);

create table if not exists public.cards (
  id uuid primary key default gen_random_uuid(),
  child_id uuid not null unique references public.children(id) on delete cascade,
  card_uid text not null unique,
  status public.card_status not null default 'ACTIVE',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.wallets (
  id uuid primary key default gen_random_uuid(),
  child_id uuid not null unique references public.children(id) on delete cascade,
  balance numeric(14, 2) not null default 0 check (balance >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.transactions (
  id uuid primary key default gen_random_uuid(),
  child_id uuid references public.children(id) on delete set null,
  canteen_id uuid references public.canteens(id) on delete set null,
  type public.transaction_type not null,
  amount numeric(14, 2) not null check (amount > 0),
  status public.transaction_status not null,
  description text,
  balance_before numeric(14, 2),
  balance_after numeric(14, 2),
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  canteen_id uuid not null references public.canteens(id) on delete cascade,
  name text not null,
  price numeric(14, 2) not null check (price >= 0),
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.transaction_items (
  id uuid primary key default gen_random_uuid(),
  transaction_id uuid not null references public.transactions(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  quantity integer not null default 1 check (quantity > 0),
  unit_price numeric(14, 2) not null check (unit_price >= 0),
  total_price numeric(14, 2) not null check (total_price >= 0),
  created_at timestamptz not null default now()
);

create table if not exists public.savings_pockets (
  id uuid primary key default gen_random_uuid(),
  child_id uuid not null references public.children(id) on delete cascade,
  name text not null,
  target_amount numeric(14, 2) not null default 0 check (target_amount >= 0),
  current_amount numeric(14, 2) not null default 0 check (current_amount >= 0),
  created_at timestamptz not null default now()
);

create table if not exists public.saving_requests (
  id uuid primary key default gen_random_uuid(),
  child_id uuid not null references public.children(id) on delete cascade,
  savings_pocket_id uuid references public.savings_pockets(id) on delete set null,
  amount numeric(14, 2) not null check (amount > 0),
  status text not null default 'PENDING' check (status in ('PENDING', 'APPROVED', 'REJECTED')),
  created_at timestamptz not null default now()
);

create table if not exists public.missions (
  id uuid primary key default gen_random_uuid(),
  child_id uuid references public.children(id) on delete cascade,
  title text not null,
  reward_amount numeric(14, 2) not null default 0 check (reward_amount >= 0),
  status text not null default 'OPEN' check (status in ('OPEN', 'DONE', 'CANCELLED')),
  created_at timestamptz not null default now()
);

create table if not exists public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_user_id uuid references public.users(id) on delete set null,
  action text not null,
  entity text not null,
  entity_id uuid,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

alter table public.users enable row level security;
alter table public.parents enable row level security;
alter table public.children enable row level security;
alter table public.canteens enable row level security;
alter table public.cards enable row level security;
alter table public.wallets enable row level security;
alter table public.transactions enable row level security;
alter table public.products enable row level security;
alter table public.transaction_items enable row level security;
alter table public.savings_pockets enable row level security;
alter table public.saving_requests enable row level security;
alter table public.missions enable row level security;
alter table public.audit_logs enable row level security;

drop policy if exists "Users can read own profile" on public.users;
create policy "Users can read own profile" on public.users for select to authenticated using (auth.uid() = id);

drop policy if exists "Parents can read own parent row" on public.parents;
create policy "Parents can read own parent row" on public.parents for select to authenticated using (auth.uid() = user_id);

drop policy if exists "Canteens can read own canteen row" on public.canteens;
create policy "Canteens can read own canteen row" on public.canteens for select to authenticated using (auth.uid() = user_id);

drop policy if exists "Children can read own child row" on public.children;
create policy "Children can read own child row" on public.children for select to authenticated using (auth.uid() = user_id);

drop policy if exists "Children can read own wallet" on public.wallets;
create policy "Children can read own wallet" on public.wallets for select to authenticated using (
  exists (select 1 from public.children where children.id = wallets.child_id and children.user_id = auth.uid())
);

drop policy if exists "Children can read own transactions" on public.transactions;
create policy "Children can read own transactions" on public.transactions for select to authenticated using (
  exists (select 1 from public.children where children.id = transactions.child_id and children.user_id = auth.uid())
);

-- ADMIN dibuat manual:
-- insert into public.users (id, email, full_name, role)
-- values ('AUTH_USER_UUID', 'admin@example.com', 'Admin KOIN', 'ADMIN');
