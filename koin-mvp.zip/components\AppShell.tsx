import Link from "next/link";
import { LogOut } from "lucide-react";
import { logoutAction } from "@/app/actions/auth";
import type { AppUser } from "@/lib/types";

export function AppShell({
  user,
  title,
  children
}: {
  user: AppUser;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <main className="min-h-screen bg-paper">
      <header className="border-b border-line bg-white">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4">
          <Link href="/dashboard" className="text-lg font-black tracking-tight">
            KOIN
          </Link>
          <div className="flex items-center gap-3">
            <div className="hidden text-right text-sm sm:block">
              <p className="font-semibold">{user.full_name}</p>
              <p className="text-ink/60">{user.role}</p>
            </div>
            <form action={logoutAction}>
              <button className="btn-secondary" type="submit">
                <LogOut size={16} />
                Keluar
              </button>
            </form>
          </div>
        </div>
      </header>
      <div className="mx-auto max-w-6xl px-5 py-8">
        <h1 className="text-2xl font-black tracking-tight sm:text-3xl">{title}</h1>
        <div className="mt-6">{children}</div>
      </div>
    </main>
  );
}
