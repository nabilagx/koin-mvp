"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { getCurrentUserProfile } from "@/lib/auth";
import { formNumber, formString } from "@/lib/format";
import { createAdminClient } from "@/lib/supabase/admin";

async function requireCanteenContext() {
  const profile = await getCurrentUserProfile();
  if (!profile) redirect("/login");
  if (profile.role !== "CANTEEN") redirect("/dashboard");

  const admin = createAdminClient();
  const { data: canteen, error } = await admin
    .from("canteens")
    .select("id,name")
    .eq("user_id", profile.id)
    .single();

  if (error || !canteen) throw new Error("Profil canteen belum tersedia.");
  return { profile, canteen, admin };
}

export async function createCanteenTransactionAction(formData: FormData) {
  const { canteen, admin } = await requireCanteenContext();
  const cardUid = formString(formData, "card_uid");
  const amount = formNumber(formData, "amount");
  const description = formString(formData, "description") || "Transaksi kantin";

  if (!cardUid || amount <= 0) throw new Error("Card UID dan nominal transaksi wajib valid.");

  const { data: card, error: cardError } = await admin
    .from("cards")
    .select("id,child_id,status")
    .eq("card_uid", cardUid)
    .maybeSingle();

  if (cardError || !card) throw new Error("Kartu tidak ditemukan.");

  const { data: child, error: childError } = await admin
    .from("children")
    .select("id,daily_limit_amount")
    .eq("id", card.child_id)
    .single();

  if (childError || !child) throw new Error("Data child tidak ditemukan.");

  const { data: wallet, error: walletError } = await admin
    .from("wallets")
    .select("id,balance")
    .eq("child_id", child.id)
    .single();

  if (walletError || !wallet) throw new Error("Wallet child belum tersedia.");

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const { data: todaysTransactions } = await admin
    .from("transactions")
    .select("amount")
    .eq("child_id", child.id)
    .eq("type", "PURCHASE")
    .eq("status", "SUCCESS")
    .gte("created_at", today.toISOString());

  const spentToday = (todaysTransactions ?? []).reduce((total, transaction) => total + Number(transaction.amount), 0);
  let failureReason = "";

  if (card.status !== "ACTIVE") failureReason = "Kartu tidak aktif.";
  else if (Number(wallet.balance) < amount) failureReason = "Saldo tidak cukup.";
  else if (spentToday + amount > Number(child.daily_limit_amount)) failureReason = "Limit harian terlampaui.";

  if (failureReason) {
    await admin.from("transactions").insert({
      child_id: child.id,
      canteen_id: canteen.id,
      type: "PURCHASE",
      amount,
      status: "FAILED",
      description: `${description}: ${failureReason}`,
      balance_before: wallet.balance,
      balance_after: wallet.balance
    });
    revalidatePath("/dashboard/canteen");
    throw new Error(failureReason);
  }

  const nextBalance = Number(wallet.balance) - amount;
  const { error: updateError } = await admin.from("wallets").update({ balance: nextBalance }).eq("id", wallet.id);
  if (updateError) throw new Error(updateError.message);

  const { error: transactionError } = await admin.from("transactions").insert({
    child_id: child.id,
    canteen_id: canteen.id,
    type: "PURCHASE",
    amount,
    status: "SUCCESS",
    description,
    balance_before: wallet.balance,
    balance_after: nextBalance
  });

  if (transactionError) throw new Error(transactionError.message);
  revalidatePath("/dashboard/canteen");
}
