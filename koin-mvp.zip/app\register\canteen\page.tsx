import Link from "next/link";
import { registerCanteenAction } from "@/app/actions/auth";
import { AuthNotice } from "@/components/AuthNotice";

export default async function RegisterCanteenPage({
  searchParams
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const params = await searchParams;

  return (
    <main className="grid min-h-screen place-items-center bg-paper px-5 py-10">
      <div className="panel w-full max-w-md rounded-lg p-6">
        <Link href="/" className="text-xl font-black">KOIN</Link>
        <h1 className="mt-8 text-2xl font-black">Register Canteen</h1>
        <div className="mt-5"><AuthNotice error={params.error} /></div>
        <form action={registerCanteenAction} className="mt-5 space-y-4">
          <label className="block text-sm font-semibold">Nama penanggung jawab<input className="field mt-1" name="full_name" required /></label>
          <label className="block text-sm font-semibold">Nama kantin<input className="field mt-1" name="canteen_name" required /></label>
          <label className="block text-sm font-semibold">Email<input className="field mt-1" name="email" type="email" required /></label>
          <label className="block text-sm font-semibold">No. HP<input className="field mt-1" name="phone" /></label>
          <label className="block text-sm font-semibold">Password<input className="field mt-1" name="password" type="password" minLength={6} required /></label>
          <button className="btn-primary w-full" type="submit">Buat akun canteen</button>
        </form>
      </div>
    </main>
  );
}
